﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace WebApiPoster.Models
    {
    public static class GlobalConnection
        {
        //MySqlConnection cn = new MySqlConnection(ConfigurationManager.ConnectionStrings["localSQL"].ToString());
        //public MySqlConnection GlobaConn { get { return cn;}}
    }
    }