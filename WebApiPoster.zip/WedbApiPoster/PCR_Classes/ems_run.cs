﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiPoster.Models
    {
    public class ems_run:PcrBase 
        {
        public string rma_text { get; set; }
        public string medical_assistance_refused { get; set; }
        public string signature { get; set; }
        public string witness_signature { get; set; }
        public string witness_name { get; set; }
        public string patient_legal_guardian { get; set; }

        public ems_run(string TableName, string id) :base(TableName ,id)
            {
            
            }
        public ems_run(string TableName, PcrJsonInputSection PcrObj)
            {
            this.TableName = TableName;
            this.PcrSection = PcrObj;
            foreach (var prop in this.GetType().GetProperties())
                {
                    prop.SetValue(this, PcrObj[prop.Name]);
                }
            }
        public void HandleRecord(int InsertUpdate = 0)
            {
            this.InsertUpdateAction( InsertUpdate);
            }
        }
    }