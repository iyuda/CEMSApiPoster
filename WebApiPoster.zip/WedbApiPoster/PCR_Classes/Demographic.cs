﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiPoster.Models
    {
    public class Demographic:PcrBase 
        {

        public string pt_person { get; set; }
        public string emr_contact_person { get; set; }
        public string phy_contact_person { get; set; }
        public string primary_policy { get; set; }
        public string secondary_policy { get; set; }
        public string terciary_insurance { get; set; }
        public string agency_id { get; set; }

        public string GetTableName()
            {
            return TableName;
            }
        public Demographic(string TableName, string id):base(TableName ,id)
            {
            
            }
        public Demographic(string TableName, PcrJsonInputSection PcrObj)
            {
            this.TableName = TableName;
            this.PcrSection = PcrObj;
            this.id = PcrObj["id"];
            this.pt_person = PcrObj["pt_person"];
            this.emr_contact_person = PcrObj["emr_contact_person"];
            this.phy_contact_person = PcrObj["phy_contact_person"];
            this.primary_policy = PcrObj["primary_policy"];
            this.secondary_policy = PcrObj["secondary_policy"];
            this.terciary_insurance = PcrObj["terciary_insurance"];
            this.agency_id = PcrObj["agency_id"];
            }
        public void HandleRecord(int InsertUpdate = 0)
            {
            this.ValidateFields();
            this.InsertUpdateAction(InsertUpdate);
            
            }
        public void ValidateFields()
            {
            if (pt_person != null) Utilities.ValidateField("person", pt_person);
            if (emr_contact_person != null) Utilities.ValidateField("person", emr_contact_person);
            if (phy_contact_person != null) Utilities.ValidateField("person", phy_contact_person);

            Insurance_Policy insurance_policy = new Insurance_Policy("insurance_policy", primary_policy);
            insurance_policy.insurance = Guid.NewGuid().ToString ();
            insurance_policy.policy_holder = Guid.NewGuid().ToString();
            insurance_policy.HandleRecord();
            
            insurance_policy = new Insurance_Policy("insurance_policy", secondary_policy);
            insurance_policy.insurance = Guid.NewGuid().ToString();
            insurance_policy.policy_holder = Guid.NewGuid().ToString();
            insurance_policy.HandleRecord();

            insurance_policy = new Insurance_Policy("insurance_policy", terciary_insurance);
            insurance_policy.insurance = Guid.NewGuid().ToString();
            insurance_policy.policy_holder = Guid.NewGuid().ToString();
            insurance_policy.HandleRecord();

            Agency agency = new Agency("agency", agency_id);
            agency.business_id = Guid.NewGuid().ToString();
            agency.HandleRecord();


            }
        }
    }