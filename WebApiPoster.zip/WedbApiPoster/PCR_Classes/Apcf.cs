﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Text;
using System.Configuration;
using System.Globalization;
namespace WebApiPoster.Models
    {
    
    public class Apcf:PcrBase 
        {
        
        public Apcf(string TableName, PcrJsonInputSection PcrObjt)
            {
            this.TableName = TableName;
            //this.Assessment_facility_id = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            //this.address_id = objAssessment.cad;
            //this.out_of_area = objAssessment.transported_from;
            //this.out_of_area_exists = null;

            }
      
 
        public string reason_appointment { get; set; }
        public string reason_ambulance { get; set; }
        public string reason_medical { get; set; }
        public string physician_name { get; set; }
        public string date_appointment { get; set; }
        public string xml_physician_signature { get; set; }
        public string ems_emt_name { get; set; }
        public string patient_bed_confined { get; set; }
        public string title { get; set; }
        public string patient_bed_confined_after_transport { get; set; }

        public void HandleRecord(int InsertUpdate = 0)
            {
            this.InsertUpdateAction( InsertUpdate);

            }

        }
    }