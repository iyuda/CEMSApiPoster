﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiPoster.Models
    {
    public class Insurance_Policy:PcrBase 
        {

        public string insurance { get; set; }
        public string policy_no { get; set; }
        public string group_no { get; set; }
        public string policy_holder { get; set; }


        public Insurance_Policy(string TableName, string id):base(TableName , id)
            {
            
            }
      
        public void HandleRecord(int InsertUpdate = 0)
            {
            if (insurance != null) Utilities.ValidateField("insurance", insurance);
            if (policy_holder != null) Utilities.ValidateField("person", policy_holder);
            this.InsertUpdateAction();
            }
        }
        }
    