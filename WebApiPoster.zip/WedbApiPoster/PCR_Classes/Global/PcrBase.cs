﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Text;
using System.Configuration;
using System.Globalization;
using System.Reflection;

namespace WebApiPoster.Models
    {
    public class PcrBase
        {
        protected PcrJsonInputSection PcrSection;
        protected string TableName;
        public string id { get; set; }
        public string GetTableName()
            {
            return TableName;
            }
        public PcrBase()
            {

            }
        public PcrBase(string TableName, string id)
            {
            this.id = id;
            this.TableName = TableName;
            }
        public  Boolean Insert(string[] Columns, string[] Values)
            {
            try
                {
                string strConnect = ConfigurationManager.ConnectionStrings["localSQL"].ToString();
                using (MySqlConnection cn = new MySqlConnection(strConnect))
                    {
                    cn.Open();

                    string InsertString = "insert into " + TableName + "(" + string.Join(",", Columns).ToString() + ") values (" + string.Join(",", Values).ToString() + ")";
                    MySqlCommand cmd = new MySqlCommand(InsertString, cn);
                    int rows = cmd.ExecuteNonQuery();
                    return rows > 0;
                    }

                }
            catch (Exception ex) { ErrorLog.LogException(ex); return false; }
            }

        public  Boolean Insert()
            {
            try
                {
                string strConnect = ConfigurationManager.ConnectionStrings["localSQL"].ToString();
                using (MySqlConnection cn = new MySqlConnection(strConnect))
                    {
                    cn.Open();

                    StringBuilder ColumnList = new StringBuilder();
                    StringBuilder ValueList = new StringBuilder();
                    for (int i = 0; i <= this.GetType().GetProperties().Length - 1; i++)
                        {
                        ColumnList.Append(this.GetType().GetProperties()[i].Name);
                        var Value = this.GetType().GetProperties()[i].GetValue(this, null);

                        Boolean boolValue;
                        if (Boolean.TryParse(Value == null ? "" : Value.ToString(), out boolValue))
                            Value = Convert.ToInt16(Convert.ToBoolean(Value)).ToString();

                        DateTime dateValue;
                        if (DateTime.TryParse(Value == null ? "" : Value.ToString(), out dateValue))
                            Value = Convert.ToDateTime(Value).ToString("yyyy-MM-dd hh:mm:ss");

                        ValueList.Append(Value == null ? "null" : "'" + Value + "'");
                        if (i < this.GetType().GetProperties().Length - 1)
                            {
                            ColumnList.Append(",");
                            ValueList.Append(",");
                            }
                        }
                    string InsertString = "insert into " + TableName + "(" + ColumnList.ToString() + ") values (" + ValueList.ToString() + ")";
                    MySqlCommand cmd = new MySqlCommand(InsertString, cn);
                    int rows = cmd.ExecuteNonQuery();
                    return rows > 0;
                    }

                }
            catch (Exception ex) { ErrorLog.LogException(ex); return false; }
            }
        public  Boolean Update(string KeyField = "id")
            {
            try
                {
                string strConnect = ConfigurationManager.ConnectionStrings["localSQL"].ToString();
                using (MySqlConnection cn = new MySqlConnection(strConnect))
                    {
                    cn.Open();
                    string UpdateString = "update " + TableName + " set " + System.Environment.NewLine;
                    StringBuilder Assignments = new StringBuilder();
                    for (int i = 0; i <= this.GetType().GetProperties().Length - 1; i++)
                        {
                        var prop = this.GetType().GetProperties()[i];
                        var Value = prop.GetValue(this, null);

                        Boolean boolValue;
                        if (Boolean.TryParse(Value == null ? "" : Value.ToString(), out boolValue))
                            Value = Convert.ToInt16(Convert.ToBoolean(Value)).ToString();

                        DateTime dateValue;
                        if (DateTime.TryParse(Value == null ? "" : Value.ToString(), out dateValue))
                            Value = Convert.ToDateTime(Value).ToString("yyyy-MM-dd hh:mm:ss");


                        string MaybeComma = i < this.GetType().GetProperties().Length - 1 ? "," : "";
                        if (prop.Name != KeyField) Assignments.Append(prop.Name + " = " + (Value == null ? "null" : "'" + Value + "'") + MaybeComma + System.Environment.NewLine);
                        }
                    Assignments.Append("where id ='" + this.GetType().GetProperty("id").GetValue(this, null) + "'"); //.GetProperties()["id"].GetValue(WorkObject,null) + "'");
                    UpdateString += Assignments.ToString();
                    MySqlCommand cmd = new MySqlCommand(UpdateString, cn);
                    int rows = cmd.ExecuteNonQuery();
                    return rows > 0;
                    }

                }
            catch (Exception ex) { ErrorLog.LogException(ex); return false; }
            }
        public  Boolean Exists(string id="") //object WorkObject)
            {
            if (id=="") id =this.id;
            string strSQL = ConfigurationManager.ConnectionStrings["localSQL"].ToString();
            using (MySqlConnection cn = new MySqlConnection(strSQL))
                {
                cn.Open();
                string SqlString = "select count(*) from " + TableName + " where id = '" + id + "'"; // WorkObject.GetType().GetProperty("id").GetValue(WorkObject, null) + "'";
                MySqlCommand cmd = new MySqlCommand(SqlString, cn);
                int rc = System.Convert.ToInt32(cmd.ExecuteScalar().ToString());
                return rc > 0;
                }
            }
        public  Boolean Exists(string[] Fields, string[] Values)
            {
            string strSQL = ConfigurationManager.ConnectionStrings["localSQL"].ToString();
            StringBuilder Comparisons = new StringBuilder();
            using (MySqlConnection cn = new MySqlConnection(strSQL))
                {
                cn.Open();
                for (int i = 0; i <= Fields.Length - 1; i++)
                    {
                    Comparisons.Append(Fields[i] + " = '" + Values[i] + "'" + (i < Fields.Length - 1 ? " and " : ""));
                    }
                string SqlString = "select count(*) from " + TableName + " where " + Comparisons.ToString(); // WorkObject.GetType().GetProperty("id").GetValue(WorkObject, null) + "'";
                MySqlCommand cmd = new MySqlCommand(SqlString, cn);
                int rc = System.Convert.ToInt32(cmd.ExecuteScalar().ToString());
                return rc > 0;
                }
            }
     
        public void ValidateField()
            {
            if (!Exists())
                Insert();
            }
        public void ValidateField(string[] Fields, string[] Values)
            {
            if (!Exists(Fields, Values))
                Insert(Fields, Values);
            }

        public void InsertUpdateAction(int InsertUpdate = 0)
            {
            switch (InsertUpdate)
                {
                case 0:
                    if (Exists())
                        Update();
                    else
                        Insert();
                    break;
                case 1:
                    Insert();
                    break;
                case 2:
                    Update();
                    break;
                }
            }
        }
    }