﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiPoster.Models
    {
    public class Agency 
        {
        public string TableName;
        public string id { get; set; }
        public string business_id { get; set; }

        public string GetTableName()
            {
            return TableName;
            }
        public Agency(string TableName, string id)
            {
            this.id = id;
            this.TableName = TableName;
            }
      
        public void HandleRecord(int InsertUpdate = 0)
            {
            if (business_id == null) business_id = Guid.NewGuid().ToString();
            Utilities.ValidateField("business", business_id);
            Utilities.InsertUpdateAction(InsertUpdate);
            }
        }
    }